<?php
$authcode='acb57db320dda6d7e1d21bce4fd20533';
$distid='1';

?>