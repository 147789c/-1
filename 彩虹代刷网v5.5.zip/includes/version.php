<?php
define('VERSION', '2001');
define('DB_VERSION', '2001');
?>