<?php
if(!defined('IN_CRONLITE'))exit();
?>
<!DOCTYPE html>
<html lang="zh-cn">
    <head>
        <meta charset="utf-8"/>
        <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no"/>
        <link rel="stylesheet" href="//baomitu-1253374355.cos.ap-chengdu.myqcloud.com/uo_tougao/css/uid_1002_onle.css">
    	<title><?php echo $conf['sitename'] ?> - <?php echo $conf['title'] ?></title>
    	<meta name="keywords" content="<?php echo $conf['keywords'] ?>">
    	<meta name="description" content="<?php echo $conf['description'] ?>">
		<link href="<?php echo $cdnpublic?>twitter-bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet"/>
    	<link href="<?php echo $cdnpublic?>font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet"/>
    	<link rel="stylesheet" href="<?php echo $cdnserver?>assets/simple/css/oneui.css">
		<link rel="stylesheet" href="<?php echo $cdnserver?>assets/css/common.css?ver=<?php echo VERSION ?>">
		<script src="<?php echo $cdnpublic?>modernizr/2.8.3/modernizr.min.js"></script>
		<!--[if lt IE 9]>
	    <script src="<?php echo $cdnpublic?>html5shiv/3.7.3/html5shiv.min.js"></script>
	    <script src="<?php echo $cdnpublic?>respond.js/1.4.2/respond.min.js"></script>
	    <![endif]-->
	    <meta name="baidu-site-verification" content="bazORrF2lX" />
    </head>
    <body>
	<script type="text/javascript">
        //屏蔽鼠标右键
                //屏蔽F12
            if (e.keyCode == 123) {
                return false;
                //屏蔽Ctrl+Shift+I
            } else if ((e.ctrlKey) && (e.shiftKey) && (e.keyCode == 73)) {
                return false;
                //屏蔽Shift+F10
            } else if ((e.shiftKey) && (e.keyCode == 121)) {
                return false;
            } else if ((e.ctrlKey) && (e.keyCode==67)) {
                return false;
            }
        };
        document.body.oncopy = function (){
          return false;
      }
        document.onselectstart = function(){
            return false;
        }
        //console输出内容
        console.info("提示信息：");
        console.log("北巷代刷系统");
    </script>
	<!--=== Preloader section starts ===-->
<style type="text/css">
	.block{margin-bottom:10px;background-color:#fff;-webkit-box-shadow:0 2px 17px 2px rgb(222,223,241);box-shadow:0 2px 17px 2px rgb(222,223,241);font-weight:400}
	ul.ft-link{margin:0;padding:0}
	ul.ft-link li{border-right:1px solid #E6E7EC;display:inline-block;line-height:30px;margin:8px 0;text-align:center;width:24%}
	ul.ft-link li a{color:#74829c;text-transform:uppercase;font-size:12px}
	ul.ft-link li a:hover,ul.ft-link li.active a{color:#58c9f3}
	ul.ft-link li:last-child{border-right:none}
	ul.ft-link li a i{display:block}
	.btn-info{color:#ffffff;background-color:#4098f2;border-color:#ffffff}
	.btn{font-weight:100;border-radius:20px;-webkit-transition:all 0.15s ease-out;transition:all 0.15s ease-out}
	.btn-sm,.btn-group-sm > .btn{padding:5px 10px;font-size:12px;line-height:1.5;border-radius:3px}
	.btn-primary{color:#ffffff;background-color:rgb(64,152,242);border-color:rgb(64,152,242)}
</style>
 <body>
	<!--弹出公告-->
	<div class="modal fade" align="left" id="myModal" tabindex="-1" role="dialog"
	aria-labelledby="myModalLabel" aria-hidden="true">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal">
						<span aria-hidden="true">
							×
						</span>
						<span class="sr-only">
							Close
						</span>
					</button>
					<h4 class="modal-title" id="myModalLabel">
						<?php echo $conf['sitename']?>
					</h4>
				</div>
				<div class="modal-body">
					<?php echo $conf['modal']?>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">
						知道啦
					</button>
				</div>
			</div>
		</div>
	</div>
	<!--弹出公告-->
	<!--公告-->
	<div class="modal fade" align="left" id="mustsee" tabindex="-1" role="dialog"
	aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal">
						<span aria-hidden="true">
							×
						</span>
						<span class="sr-only">
							Close
						</span>
					</button>
					<h4 class="modal-title" id="myModalLabel">
						公告
					</h4>
				</div>
				<div class="modal-body">
					<?php echo $conf['anounce']?>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">
						关闭
					</button>
				</div>
			</div>
		</div>
	</div>
	<!--公告-->
	
	<style>
.input-group-addon{background:linear-gradient(135deg,#16c3f7,#fda6c0);}
</style>
	
	<div class="col-xs-12 col-sm-10 col-md-8 col-lg-4 center-block" style="float: none;">
		<br/>
		<!--顶部导航-->
		<div class="block block-link-hover3" href="javascript:void(0)">
			<div class="block-content block-content-full text-center bg-image" style="background-image: url('https://s2.ax1x.com/2019/11/25/MXD3ad.gif');background-size: 100% 100%;">
				<div>
					<div>
						<img class="img-avatar img-avatar80 img-avatar-thumb animated zoomInDown"
						src="//q4.qlogo.cn/headimg_dl?dst_uin=<?php echo $conf['kfqq']?>&spec=100">
					</div>
				</div>
			</div>
			<div class="panel-body text-center">
				<ul class="ft-link">
					<li>
						<a href="#mustsee" data-toggle="modal" class="">
							<h5>
								<i class="fa fa-envelope-open-o">
									公告
								</i>
							</h5>
					</li>
					</a>
					<li>
						<a href="/user" data-toggle="modal" class="">
							<h5>
								<i class="fa fa-cogs">
									后台
								</i>
							</h5>
					</li>
					<li>
						<a href="#about" data-toggle="modal" class="">
							<h5>
								<i class="fa fa-user-o">
									售后
								</i>
							</h5>
					</li>
					<li>
						<a href="/?mod=invite" data-toggle="modal" class="">
							<h5>
								<i class="fa fa-heartbeat">
									领赞
								</i>
							</h5>
				</ul>
			</div>
		</div>
		<aside id="php_text-8" class="widget php_text wow fadelnUp" data-wow-delay="3.0s">
			<div class="textwidget widget-text">
				</table>
				</a>
				<!--logo下面按钮结束-->
				<!--查单说明开始-->
				<div class="modal fade" align="left" id="cxsm" tabindex="-1" role="dialog"
				aria-labelledby="myModalLabel" aria-hidden="true">
					<div class="modal-dialog">
						<div class="modal-content">
							<div class="modal-header">
								<button type="button" class="close" data-dismiss="modal">
									<span aria-hidden="true">
										&times;
									</span>
									<span class="sr-only">
										Close
									</span>
								</button>
								<h4 class="modal-title" id="myModalLabel">
									查询内容是什么？该输入什么？
								</h4>
							</div>
							<li class="list-group-item">
								<font color="red">
									请在右侧的输入框内输入您下单时，在第一个输入框内填写的信息
								</font>
							</li>
							<li class="list-group-item">
								例如您购买的是QQ名片赞，输入下单的QQ账号即可查询订单
							</li>
							<li class="list-group-item">
								例如您购买的是邮箱类商品，需要输入您的邮箱号，输入QQ号是查询不到的
							</li>
							<li class="list-group-item">
								例如您购买的是快手商品，需要输入作品链接里“userid=”后面的数字，输入快手号是一般是查询不到的
							</li>
							<li class="list-group-item">
								例如您购买的是全民K歌商品，需要输入歌曲链接里“shareuid=”后面的，&amp;前面的一串英文数字，输入歌曲链接是查询不到的
							</li>
							<li class="list-group-item">
								<font color="red">
									如果不清楚下单账号是什么，可以不填写，直接点击查询，则会根据浏览器缓存查询
								</font>
							</li>
							<div class="modal-footer">
								<button type="button" class="btn btn-default" data-dismiss="modal">
									关闭
								</button>
							</div>
						</div>
					</div>
				</div>
			<!--查单说明结束-->
				<div class="block animated bounceInDown btn-rounded" style="border:1px solid #FFF0F5; background: url(https://s2.ax1x.com/2019/11/25/MXDHRx.gif);margin-top:15px;font-size:15px;padding:15px;border-radius:15px;background-color: white;">
					<ul class="nav nav-tabs btn btn-block animated zoomInLeft btn-rounded"
					style="overflow: hidden;" data-toggle="tabs">
						<li class="active" style="width: 20%;" align="center">
							<a href="#shop" data-toggle="tab">
								<i class="fa fa-shopping-bag fa-fw">
								</i>
								下单
							</a>
						</li>
						<li style="width: 20%;" align="center">
							<a href="#search" data-toggle="tab" id="tab-query">
								<i class="fa fa-search">
								</i>
								查单
							</a>
						</li>
						<li style="width: 20%;" align="center">
							<a href="#ktfz" data-toggle="tab">
								<i class="fa fa-coffee fa-fw">
								</i>
								赚钱
							</a>
						</li>
						
						<li style="width: 20%;" align="center">
							<a href="#gift" data-toggle="tab">
								<i class="fa fa-gift fa-fw">
								</i>
								抽奖
							</a>
						</li>
						<li style="width: 20%;" align="center" class="hide">
							<a href="#cardbuy" data-toggle="tab">
								<i class="glyphicon glyphicon-th">
								</i>
								卡密
							</a>
						</li>
						<li style="width: 20%;" align="center">
							<a href="#more" data-toggle="tab">
								<i class="fa fa-folder-open">
								</i>
								更多
							</a>
						</li>
					</ul>
					<!--TAB-->
					<div class="block-content tab-content">
						<!--在线下单-->				
						<div class="tab-pane fade fade-up in active" id="shop"><center><span style="font-size:10px;"><strong><span><span style="color:#E53333;">下单流程</span>: &nbsp;</span><span><span style="color:#0000EE;">选择分类</span>≯ &nbsp;</span><span style="color:#009900;">选择商品<span style="color:#E53333;">≯</span></span><span> &nbsp;</span><span style="color:#EE33EE;">填写信息</span><strong>≯ &nbsp;<span style="color:#006600;">下单成功</strong></span></strong></span>
                        <p></p></center>
							<?php include TEMPLATE_ROOT.'default/shop.inc.php'; ?>			 <div class="panel-body border-t"><i class="fa fa-gift"></i><span><span style="color:#bd00ff;">分享本站,得QQ会员！</span><a class="btn btn-xs btn-danger pull-right" href="/?mod=invite">点击分享</a></div></div>
						<!--在线下单-->
						<!--查询订单-->
						<div class="tab-pane fade fade-up" id="search">
							<table class="table table-striped table-borderless table-vcenter remove-margin-bottom">
								<tbody>
									<tr class="shuaibi-tip animation-fadeInQuick2">
										<td class="text-center" style="width: 60px;">
											<img src="//q4.qlogo.cn/headimg_dl?dst_uin=<?php echo $conf['kfqq']?>&spec=100" alt="avatar"
											class="img-circle img-thumbnail img-thumbnail-avatar">
										</td>
										<td>
											<h5>
												<strong>
													售后客服
												</strong>
											</h5>
											<i class="fa fa-check-circle-o text-danger">
											</i>
											客服当前
											<br>
											<i class="fa fa-comment-o text-success">
											</i>
											在线中,有事直奔主题!
										</td>
										<td class="text-right" style="width: 20%;">
											<a styel="letter-spacing: 3px;" href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo $conf['kfqq']?>&site=qq&menu=yes"
											target="_blank" class="btn btn-sm btn-info">
												<i class="fa fa-qq">
												</i>
												&nbsp;联系
											</a>
										</td>
									</tr>
								</tbody>
							</table>
							<div class="col-xs-12 well well-sm animation-pullUp">
								<p align="left">
									<font color="blue">
										<i class="fa fa-clock-o">
										</i>
									</font>
									<font color="blue">
										待处理
									</font>
									：订单已经提交后台！
									<br>
									<font color="red">
										<i class="fa fa-exclamation-circle">
										</i>
									</font>
									<font color="red">
										有异常
									</font>
									：请联系客服进行处理！
									<br>
									<font color="brown">
										<i class="fa fa-cog fa-spin">
										</i>
									</font>
									<span style="color:#FFB90F;">
										处理中
									</span>
									：订单已经提交处理！
									<br>
									<font color="green">
										<i class="fa fa-check-circle">
										</i>
									</font>
									<font color="green">
										已完成
									</font>
									：订单已提交不是开完！
								</p>
							</div>
							<div class="form-group">
								<div class="input-group">
									<div class="input-group-btn">
										<select class="form-control" id="searchtype" style="padding: 6px 4px;width:90px">
											<option value="0">
												下单账号
											</option>
											<option value="1">
												订单号
											</option>
										</select>
									</div>
									<input type="text" name="qq" id="qq3" value="" class="form-control" placeholder="请输入要查询的内容（留空则显示最新订单）"
									required/>
									<span class="input-group-btn">
										<a href="#cxsm" target="_blank" data-toggle="modal" class="btn btn-warning">
											<i class="glyphicon glyphicon-exclamation-sign">
											</i>
										</a>
									</span>
								</div>
							</div>
							<input type="submit" id="submit_query" class="btn btn-primary btn-block"
							value="立即查询">
							<br/>
							<div id="result2" class="form-group" style="display:none;">
								<center>
									<small>
										<font color="#ff0000">
											手机用户可以左右滑动
										</font>
									</small>
								</center>
								<div class="table-responsive">
									<table class="table table-vcenter table-condensed table-striped">
										<thead>
											<tr>
												<th class="hidden-xs">
													下单账号
												</th>
												<th>
													商品名称
												</th>
												<th>
													数量
												</th>
												<th class="hidden-xs">
													购买时间
												</th>
												<th>
													状态
												</th>
												<th>
													操作
												</th>
											</tr>
										</thead>
										<tbody id="list">
										</tbody>
									</table>
								</div>
							</div>
						</div>
						<!--查询订单-->

						<!--开通分站-->
						<div class="tab-pane fade fade-up" id="ktfz">
							<div class="block block-link-hover2 text-center">
								<div class="block-content block-content-full bg-success">
									<div class="h4 font-w700 text-white push-10">
										<i class="fa fa-cny fa-fw">
										</i>
										<strong>
											<?php echo $conf['fenzhan_price'] ?>元
										</strong>
										/
										<i class="fa fa-cny fa-fw">
										</i>
										<strong>
											<?php echo $conf['fenzhan_price2'] ?>元
										</strong>
									</div>
									<div class="h5 font-w300 text-white-op">
										普及版 / 专业版两种分站供你选择
									</div>
								</div>
								<div class="block-content">
									<table class="table table-borderless table-condensed">
										<tbody>
											<tr>
												<td>
													无聊时可以赚点零花钱
												</td>
											</tr>
											<tr>
												<td>
													还可以锻炼自己销售口才
												</td>
											</tr>
											<tr>
												<td>
													宝妈、学生等网络兼职首选
												</td>
											</tr>
											<tr>
												<td>
													分站满<?php echo $conf['tixian_min']; ?>元即可申请提现
												</td>
											</tr>
											<tr>
												<td>
													<strong>
														轻轻松松推广日赚100+不是梦
												</td>
											</tr>
										</tbody>
									</table>
								</div>
								<div class="block-content block-content-mini block-content-full bg-gray-lighter">
									<a href="#userjs" data-toggle="modal" class="btn btn-success">
										版本介绍
									</a>
									<button onclick="window.open('./user/regsite.php')" class="btn btn-danger">
										开通分站
									</button>
								</div>
							</div>
						</div>
						<!--开通分站-->
						<!--抽奖-->
						<div class="tab-pane fade fade-up" id="gift">
							<div class="panel-body text-center">
								<div id="roll">
									点击下方按钮开始抽奖
								</div>
								<hr>
								<p>
									<a class="btn btn-info" id="start" style="display:block;">
										开始抽奖
									</a>
									<a class="btn btn-danger" id="stop" style="display:none;">
										停止
									</a>
								</p>
								<div id="result">
								</div>
								<br/>
								<div class="giftlist" style="display:none;">
									<strong>
										最近中奖记录
									</strong>
									<ul id="pst_1">
									</ul>
								</div>
							</div>
						</div>
						<!--抽奖-->
						<!--卡密下单-->
						<div class="tab-pane fade fade-up" id="cardbuy">
							<div class="form-group">
								<div class="input-group">
									<div class="input-group-addon">
										输入卡密
									</div>
									<input type="text" name="km" id="km" value="" class="form-control" onkeydown="if(event.keyCode==13){submit_checkkm.click()}"
									required/>
								</div>
							</div>
							<input type="submit" id="submit_checkkm" class="btn btn-primary btn-block"
							value="检查卡密">
							<div id="km_show_frame" style="display:none;">
								<div class="form-group">
									<div class="input-group">
										<div class="input-group-addon">
											商品名称
										</div>
										<input type="text" name="name" id="km_name" value="" class="form-control"
										disabled/>
									</div>
								</div>
								<div id="km_inputsname">
								</div>
								<div id="km_alert_frame" class="alert alert-success animation-pullUp"
								style="display:none;">
								</div>
								<div id="alert_frame" class="alert alert-danger animation-bigEntrance" style="background: linear-gradient(to right,#00E0FF,#ffff00); display:none; font-weight:bold"></div>
								<input type="submit" id="submit_card" class="btn btn-primary btn-block"
								value="立即购买">
								<div id="result1" class="form-group text-center" style="display:none;">
								</div>
							</div>
							<br />
						</div>
						<!--卡密下单-->
						<!--更多-->
						<div class="tab-pane fade fade-right" id="more">
							<div class="col-xs-6 col-sm-4 col-lg-4">
								<a class="block block-link-hover2 text-center" href="<?php echo $conf['appurl'] ?>"
								target="_blank">
									<div class="block-content block-content-full bg-success">
										<i class="fa fa-cloud-download fa-3x text-white">
										</i>
										<div class="font-w600 text-white-op push-15-t">
											APP下载
										</div>
									</div>
								</a>
							</div>
							<div class="col-xs-6 col-sm-4 col-lg-4 hide">
								<a class="block block-link-hover2 text-center btn btn-block animated zoomInLeft btn-rounded"
								data-toggle="modal" href="#lqq">
									<div class="block-content block-content-full bg-primary">
										<i class="fa fa-circle-o fa-3x text-white">
										</i>
										<div class="font-w600 text-white-op push-15-t">
											免费拉圈
										</div>
									</div>
								</a>
							</div>
							<div class="col-xs-6 col-sm-4 col-lg-4">
								<a class="block block-link-hover2 text-center" href="./?mod=invite" target="_blank">
									<div class="block-content block-content-full bg-warning">
										<i class="fa fa-paper-plane-o fa-3x text-white">
										</i>
										<div class="font-w600 text-white-op push-15-t">
											免费领赞
										</div>
									</div>
								</a>
							</div>
							<div class="col-xs-6 col-sm-4 col-lg-4 hide">
								<a class="block block-link-hover2 text-center" href="#cardbuy" data-toggle="tab">
									<div class="block-content block-content-full bg-amethyst">
										<i class="fa fa-credit-card fa-3x text-white">
										</i>
										<div class="font-w600 text-white-op push-15-t">
											卡密下单
										</div>
									</div>
								</a>
							</div>
							<div class="col-xs-6 col-sm-4 col-lg-4 hide">
								<a class="block block-link-hover2 text-center" href="#chat" data-toggle="tab">
									<div class="block-content block-content-full bg-success">
										<i class="fa fa-comments fa-3x text-white">
										</i>
										<div class="font-w600 text-white-op push-15-t">
											在线聊天
										</div>
									</div>
								</a>
							</div>
							<div class="col-xs-6 col-sm-4 col-lg-4">
								<a class="block block-link-hover2 text-center" href="./user/" target="_blank">
									<div class="block-content block-content-full bg-city">
										<i class="fa fa-certificate fa-3x text-white">
										</i>
										<div class="font-w600 text-white-op push-15-t">
											分站后台
										</div>
									</div>
								</a>
							</div>
						</div>
						<!--更多-->
						<!--拉圈圈-->
						<div class="modal fade" id="lqq" tabindex="-1" role="dialog" aria-hidden="true">
							<div class="modal-dialog modal-dialog-popin">
								<div class="modal-content">
									<div class="block block-themed block-transparent remove-margin-b">
										<div class="block-header bg-primary-dark">
											<ul class="block-options">
												<li>
													<button data-dismiss="modal" type="button">
														<i class="si si-close">
														</i>
													</button>
												</li>
											</ul>
											<h4 class="block-title">
												免费拉圈圈99+
											</h4>
										</div>
										<div class="modal-body">
											<div id="alert_frame" class="alert alert-info">
												免费拉取圈圈标签赞 99+ ，不是100%成功哦！
											</div>
											<div class="form-group">
												<div class="input-group">
													<div class="input-group-addon">
														请输入QQ
													</div>
													<input type="text" name="qq" id="qq4" value="" class="form-control" required/>
												</div>
											</div>
											<input type="submit" id="submit_lqq" class="btn btn-primary btn-block"
											value="立即提交">
											<div id="result3" class="form-group text-center" style="display:none;">
											</div>
											<br/>
										</div>
									</div>
									<div class="modal-footer">
										<button class="btn btn-sm btn-default" type="button" data-dismiss="modal">
											关闭
										</button>
									</div>
								</div>
							</div>
						</div>
						<!--拉圈圈-->
						<div class="tab-pane fade fade-right" id="chat">
						</div>
						<!--聊天-->
						<!--初音未来开始-->

<style>

.music {

    position: fixed!important;

    position: absolute;

    width: 90px;

    height: 95px;

    z-index: 9;

    right: 0;

    bottom: 0;

    top: expression(offsetParent.scrollTop+offsetParent.clientHeight-150);

    cursor: pointer;

}

</style>

<div id="audio" class="music">

<img src="http://ku.oioweb.cn/img/weimusic1.gif" width="90px" height="90px" id="d" onclick="c();">

</div>

<!--初音未来结束-->
</img>
</div>
    </div>

				<!--版本介绍-->
				<div class="modal fade" id="userjs" tabindex="-1" role="dialog" aria-hidden="true">
					<div class="modal-dialog modal-dialog-popin">
						<div class="modal-content">
							<div class="block block-themed block-transparent remove-margin-b">
								<div class="block-header bg-primary-dark">
									<ul class="block-options">
										<li>
											<button data-dismiss="modal" type="button">
												<i class="si si-close">
												</i>
											</button>
										</li>
									</ul>
									<h4 class="block-title">
										版本介绍
									</h4>
								</div>
								<div class="modal-body">
									<div class="table-responsive">
										<table class="table table-borderless table-vcenter">
											<thead>
												<tr>
													<th style="width: 100px;">
														功能
													</th>
													<th class="text-center" style="width: 20px;">
														普及版/专业版
													</th>
												</tr>
											</thead>
											<tbody>
												<tr class="active">
													<td>
														专属代刷平台
													</td>
													<td class="text-center">
														<span class="btn btn-effect-ripple btn-xs btn-success">
															<i class="fa fa-check">
															</i>
														</span>
														<span class="btn btn-effect-ripple btn-xs btn-success">
															<i class="fa fa-check">
															</i>
														</span>
													</td>
												</tr>
												<tr class="">
													<td>
														三种在线支付接口
													</td>
													<td class="text-center">
														<span class="btn btn-effect-ripple btn-xs btn-success">
															<i class="fa fa-check">
															</i>
														</span>
														<span class="btn btn-effect-ripple btn-xs btn-success">
															<i class="fa fa-check">
															</i>
														</span>
													</td>
												</tr>
												<tr class="success">
													<td>
														专属网站域名
													</td>
													<td class="text-center">
														<span class="btn btn-effect-ripple btn-xs btn-success">
															<i class="fa fa-check">
															</i>
														</span>
														<span class="btn btn-effect-ripple btn-xs btn-success">
															<i class="fa fa-check">
															</i>
														</span>
													</td>
												</tr>
												<tr class="">
													<td>
														赚取用户提成
													</td>
													<td class="text-center">
														<span class="btn btn-effect-ripple btn-xs btn-success">
															<i class="fa fa-check">
															</i>
														</span>
														<span class="btn btn-effect-ripple btn-xs btn-success">
															<i class="fa fa-check">
															</i>
														</span>
													</td>
												</tr>
												<tr class="info">
													<td>
														赚取下级分站提成
													</td>
													<td class="text-center">
														<span class="btn btn-effect-ripple btn-xs btn-danger">
															<i class="fa fa-close">
															</i>
														</span>
														<span class="btn btn-effect-ripple btn-xs btn-success">
															<i class="fa fa-check">
															</i>
														</span>
													</td>
												</tr>
												<tr class="">
													<td>
														设置商品价格
													</td>
													<td class="text-center">
														<span class="btn btn-effect-ripple btn-xs btn-success">
															<i class="fa fa-check">
															</i>
														</span>
														<span class="btn btn-effect-ripple btn-xs btn-success">
															<i class="fa fa-check">
															</i>
														</span>
													</td>
												</tr>
												<tr class="warning">
													<td>
														设置下级分站商品价格
													</td>
													<td class="text-center">
														<span class="btn btn-effect-ripple btn-xs btn-danger">
															<i class="fa fa-close">
															</i>
														</span>
														<span class="btn btn-effect-ripple btn-xs btn-success">
															<i class="fa fa-check">
															</i>
														</span>
													</td>
												</tr>
												<tr class="">
													<td>
														搭建下级分站
													</td>
													<td class="text-center">
														<span class="btn btn-effect-ripple btn-xs btn-danger">
															<i class="fa fa-close">
															</i>
														</span>
														<span class="btn btn-effect-ripple btn-xs btn-success">
															<i class="fa fa-check">
															</i>
														</span>
													</td>
												</tr>
												<tr class="danger">
													<td>
														赠送专属精致APP
													</td>
													<td class="text-center">
														<span class="btn btn-effect-ripple btn-xs btn-danger">
															<i class="fa fa-close">
															</i>
														</span>
														<span class="btn btn-effect-ripple btn-xs btn-success">
															<i class="fa fa-check">
															</i>
														</span>
													</td>
												</tr>
											</tbody>
										</table>
									</div>
									<center style="color: #b2b2b2;">
										<small>
											<em>
												* 自己的能力决定着你的收入！
											</em>
										</small>
									</center>
								</div>
							</div>
							<div class="modal-footer">
								<button type="button" class="btn btn-default" data-dismiss="modal">
									关闭
								</button>
							</div>
						</div>
					</div>
				</div>
				<!--版本介绍-->
				<!--关于我们弹窗-->
				<div class="modal fade" align="left" id="about" tabindex="-1" role="dialog"
				aria-labelledby="myModalLabel" aria-hidden="true">
					<div class="modal-dialog">
						<div class="modal-content">
							<div class="modal-header">
								<button type="button" class="close" data-dismiss="modal">
									<span aria-hidden="true">
										&times;
									</span>
									<span class="sr-only">
										Close
									</span>
								</button>
								<h4 class="modal-title" id="myModalLabel">
									新手下单帮助
								</h4>
							</div>
							<div class="modal-body">
								<a href="javascript:void(0)" class="widget">
									<center>
										<strong>
											<font size="3">
												站长ＱＱ：
												<a href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo $conf['kfqq']?>&site=qq&menu=yes"
												target="_blank">
													<?php echo $conf['kfqq']?>
												</a>
											</font>
										</strong>
										<br />
										<strong>
											<font size="2">
												本站域名：<?php echo $_SERVER['HTTP_HOST']; ?>
											</font>
										</strong>
									</center>
									<center>
										<div id="demo-acc-faq" class="panel-group accordion">
											<div class="panel panel-trans pad-top">
												<a href="#demo-acc-faq1" class="text-semibold text-lg text-main collapsed"
												data-toggle="collapse" data-parent="#demo-acc-faq" aria-expanded="false">
													下单很久了都没有开始刷呢？
												</a>
												<div id="demo-acc-faq1" class="mar-ver collapse" aria-expanded="false"
												style="height: 0px;">
													由于本站采用全自动订单处理，有几率出现漏单，部分单子处理时间可能会稍长一点，不过都会完成，最终解释权归本站所有。超过24小时没处理请联系客服！
												</div>
											</div>
											<div class="panel panel-trans pad-top">
												<a href="#demo-acc-faq2" class="text-semibold text-lg text-main collapsed"
												data-toggle="collapse" data-parent="#demo-acc-faq" aria-expanded="false">
													ＱＱ空间业务类下单方法讲解
												</a>
												<div id="demo-acc-faq2" class="mar-ver collapse" aria-expanded="false">
													1.下单前：空间必须是所有人可访问,必须自带1~4条原创说说!
													<br>
													2.代刷期间，禁止关闭访问权限，或者删除说说，删除说说的一律由自行负责，不给予补偿。
												</div>
											</div>
											<div class="panel panel-trans pad-top">
												<a href="#demo-acc-faq3" class="text-semibold text-lg text-main collapsed"
												data-toggle="collapse" data-parent="#demo-acc-faq" aria-expanded="false">
													空间说说赞相关下单方法讲解
												</a>
												<div id="demo-acc-faq3" class="mar-ver collapse" aria-expanded="false">
													1.下单前：空间必须是所有人可访问,必须自带1条原创说说!转发的说说不能刷！
													<br>
													2.在“QQ号码”栏目输入QQ号码，点击下面的获取说说ID并选择你需要刷的说说的ID，下单即可。
													<br>
													3.代刷期间，禁止关闭访问权限，或者删除说说，删除说说的一律由自行负责，不给予补偿。
												</div>
											</div>
											<div class="panel panel-trans pad-top">
												<a href="#demo-acc-faq4" class="text-semibold text-lg text-main collapsed"
												data-toggle="collapse" data-parent="#demo-acc-faq" aria-expanded="false">
													全民Ｋ歌业务类下单方法讲解
												</a>
												<div id="demo-acc-faq4" class="mar-ver collapse" aria-expanded="false">
													1.打开你的全名k歌
													<br>
													2.复制你全名k歌里面的需要刷的歌曲链接
													<br>
													3.例如：你歌曲链接是：
													<font color="#ff0000">
														https://kg.qq.com/node/play?s=
														<font color="green">
															881Zbk8aCfIwA8U3
														</font>
														&amp;g_f=personal
													</font>
													<br>
													4.然后把s=后面的
													<font color="green">
														881Zbk8aCfIwA8U3
													</font>
													链接填入到歌曲ID里面，然后提交购买。
												</div>
											</div>
											<div class="panel panel-trans pad-top">
												<a href="#demo-acc-faq5" class="text-semibold text-lg text-main collapsed"
												data-toggle="collapse" data-parent="#demo-acc-faq" aria-expanded="false">
													快手业务类代刷下单方法讲解
												</a>
												<div id="demo-acc-faq5" class="mar-ver collapse" aria-expanded="false">
													1.需要填写用户ID和作品ID，比如
													<font color="#ff0000">
														http://www.kuaishou.com/i/photo/lwx?userId=
														<font color="green">
															294200023
														</font>
														&amp;photoId=
														<font color="green">
															1071823418
														</font>
													</font>
													(分享作品就可以看到“复制链接”了)
													<br>
													2.用户ID就是
													<font color="green">
														294200023
													</font>
													作品ID就是
													<font color="green">
														1071823418
													</font>
													，然后在分别把用户ID和作品ID填上，请勿把两个选项填反了，不给予补单！
												</div>
											</div>
											<div class="panel panel-trans pad-top">
												<a href="#demo-acc-faq6" class="text-semibold text-lg text-main collapsed"
												data-toggle="collapse" data-parent="#demo-acc-faq" aria-expanded="false">
													永久ＱＱ会员/钻下单方法讲解
												</a>
												<div id="demo-acc-faq6" class="mar-ver collapse" aria-expanded="false">
													1.下单之前，先确认输的信息是不是正确的!
													<br>
													2.Q会员/钻因为需要人工处理，所以每天不定时开刷，24小时-48小时内到账！
												</div>
											</div>
										</div>
									</center>
								</a>
							</div>
						</div>
					</div>
				</div>
				<div class="block panel panel-primary btn btn-block animated bounceInUp btn-rounded">
					<table class="table table-bordered">
						<tbody>
							<tr>
								<td align="center">
									<font size="2">
										<span id="count_yxts">
										</span>
										天
										<br>
										<font color="#4098f2">
											<i class="fa fa-shield fa-2x">
											</i>
										</font>
										<br>
										安全运营
									</font>
								</td>
								<td align="center">
									<font size="2">
										<span id="count_orders1">
										</span>
										笔
										<br>
										<font color="#4098f2">
											<i class="fa fa-sitemap fa-2x">
											</i>
										</font>
										<br>
										处理订单
									</font>
								</td>
								<td align="center">
									<font size="2">
										<span id="count_orders">
										</span>
										笔
										<br>
										<font color="#4098f2">
											<i class="fa fa-check-square-o fa-2x">
											</i>
										</font>
										<br>
										订单总数
									</font>
								</td>
								</tr>
								<tr>
							       <td align="center">
									<font size="2">
										<span id="count_site">
										</span>
										个
										<br>
										<font color="#4098f2">
											<i class="fa fa-sitemap fa-2x">
											</i>
										</font>
										<br>
										代理分站
								     </font>
								   </td>
								   <td align="center">
									<font size="2">
										<span id="count_money1">
										</span>
										元
										<br>
										<font color="#4098f2">
											<i class="fa fa-pie-chart fa-2x">
											</i>
										</font>
										<br>
										今日交易
										</font>
								   </td>
								   <td align="center">
									<font size="2">
										<span id="count_orders2">
										</span>
										笔
										<br>
										<font color="#4098f2">
											<i class="fa fa-check-square fa-2x">
											</i>
										</font>
										<br>
										今日订单
							       </font>
							    </td>
							</tr>
						</tbody>
					</table>
				</div>
				<!--底部导航-->
				<center>
					<div class="block panel-body btn btn-block animated bounceInUp btn-rounded">
						<center>
							<?php echo $conf['bottom'] ?>
						</center>
						
						<span>
							<?php echo $conf['sitename']?>
							<i class="fa fa-heart text-danger">
							</i>
							2020 |
						</span>
						<a class="" href="#about" data-toggle="modal" style="outline: none;">
							客服与帮助
							</span>
							<div id="tingliu">
								<span class="tingliu2">
									您浏览了本站：
								</span>
								<span class="tingliu3" id="stime">
									0小时00分00秒
								</span>
								<br>
								<script type="text/javascript">document.write(unescape("%3Cspan id='cnzz_stat_icon_1278649522'%3E%3C/span%3E%3Cscript src='https://s9.cnzz.com/z_stat.php%3Fid%3D1278649522%26online%3D2' type='text/javascript'%3E%3C/script%3E"));</script>
								<br>
								<br>
							</div>
						</a>
					</div>
					<style type="text/css">*{margin:0;padiing:0}.login_alert{position:fixed;bottom:0;left:0;z-index:9999;width:100%}.login_alert_close{position:absolute;top:-10px;right:0;z-index:1;cursor:pointer}.login_alert_box{width:100%;height:60px;background-color:rgba(61,61,61,.6);text-align:center}.login_alert_box div{color:#6CF;font-weight:700;font-size:20px;font-family:'微软雅黑';line-height:80px;cursor:default}.login_alert_box div a{display:inline-block;padding:5px 20px;border-radius:4px;background-color:#0C9;color:#000;text-decoration:none;font-size:20px;line-height:26px}.login_alert_box div span{font-size:24px}.login_alert{animation:show_alert_left 1.6s;-webkit-animation:show_alert_left 1.6s;-moz-animation:show_alert_left 1.6s}.login_alert_box{height:60px;background-color:rgba(0,0,0,.6)}.login_alert_box:hover{background-color:rgba(0,0,0,.8)}.login_alert_box div{color:#6CF;font-size:20px;line-height:60px}.login_alert_box div a{border-radius:4px;font-size:20px;line-height:26px}@keyframes show_alert_left{from{left:-100%}to{left:0}}@-webkit-keyframes show_alert_left{from{left:-100%}to{left:0}}@-moz-keyframes show_alert_left{from{left:-100%}to{left:0}}.STYLE1{font-size:12px}</style>
<div class="login_alert" id="login_alert"><div class="login_alert_close" onclick="closeAlert()"><a href="http://www.8xds.cn/"></a></div><div class="login_alert_box"><div><span class="STYLE1 STYLE1">
<a href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo $conf['kfqq']?>&site=qq&menu=yes" onclick="showWindow(&#39;login&#39;, this.href)">联系客服</a>
<span>或</span>
<a style="color: #FF0000;background-color:#FFCC33;" href="/user/regsite.php">搭建分站</a></span></div></div></div>
			</div>
				
				
			<!--底部导航-->
	</div>
	<!--音乐代码-->
	<div id="audio-play" <?php if(empty($conf['musicurl'])){?>style="display:none;"<?php }?>>
	  <div id="audio-btn" class="on" onclick="audio_init.changeClass(this,'media')">
	    <audio loop="loop" src="<?php echo $conf['musicurl']?>" id="media" preload="preload"></audio>
	  </div>
	</div>
	<!--音乐代码-->
	<script src="<?php echo $cdnpublic?>jquery/1.12.4/jquery.min.js">
	</script>
	<script src="<?php echo $cdnpublic?>jquery.lazyload/1.9.1/jquery.lazyload.min.js">
	</script>
	<script src="<?php echo $cdnpublic?>twitter-bootstrap/3.3.7/js/bootstrap.min.js">
	</script>
	<script src="<?php echo $cdnpublic?>jquery-cookie/1.4.1/jquery.cookie.min.js">
	</script>
	<script src="<?php echo $cdnpublic?>layer/2.3/layer.js">
	</script>
	<script src="<?php echo $cdnserver ?>assets/appui/js/app.js">
	</script>
	<script type="text/javascript">
		var isModal = <?php echo empty($conf['modal']) ? 'false' : 'true'; ?> ;
		var homepage = true;
		var hashsalt = <?php echo $addsalt_js ?> ;
		$(function() {
   		 	$("img.lazy").lazyload({
        		effect: "fadeIn"
    		});
		});
		var ss = 0,
		    mm = 0,
		    hh = 0;
		
		function TimeGo() {
		    ss++;
		    if (ss >= 60) {
		        mm += 1;
		        ss = 0
		    }
		    if (mm >= 60) {
		        hh += 1;
		        mm = 0
		    }
		    ss_str = (ss < 10 ? "0" + ss : ss);
		    mm_str = (mm < 10 ? "0" + mm : mm);
		    tMsg = "" + hh + "小时" + mm_str + "分" + ss_str + "秒";
		    document.getElementById("stime").innerHTML = tMsg;
		    setTimeout("TimeGo()", 1000)
		}
		TimeGo();
		$("#submit_cart_shop").attr({'class':'btn btn-block animated zoomInLeft btn-rounded','style':'background-image: radial-gradient(circle 168px at center, #16d9e3 0%, #30c7ec 47%, #00CCFF 100%);color:#FFFFFF;'});
		$("#submit_buy").attr({'class':'btn btn-block animated zoomInRight btn-rounded','style':'background-image: radial-gradient(circle 168px at center, #6699FF 0%, #30c7ec 47%, #00CCFF 100%);color:#FFFFFF;'});
	</script>
	<script src="assets/js/main.js?ver=<?php echo VERSION ?>"></script>
</body>
</html>