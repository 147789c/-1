<?php
if(!defined('IN_CRONLITE'))exit();

include_once TEMPLATE_ROOT.'faka/head.php';
?>
<div id="bd">

<div id="bar">
<div class="bar_top">关于我们</div><br />

<ul id="bar_ul">
<li ><a href="./?mod=about">关于我们</a></li>
<li class="va"><a href="./?mod=help">帮助中心</a></li>
</ul>
</div>


<div id="bar_r">


<div id="body_xiao">
    	<div class="table">

<br/>
<span class="title"><p style="text-align: center;">
    <strong style="font-size: 30px; white-space: normal;">帮助中心</strong>
</p></span><br/>

    	
<span ><p>如何购买卡密：</p><p>第一步：先注册 一个账号 或者登陆</p><p>第二步：选购指定商品 确认够买</p><p>第三步：充值结算</p><p>第四步：完成 提取卡密</p><p>如有疑问请联系客服处理</p></span>
        	


</div>
</div>
</div>
</div></div>
<div id="footer">
    		&copy; 2020 <?php echo $conf['sitename']?>
</div>
