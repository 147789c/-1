<?php
if(!defined('IN_CRONLITE'))exit();

if($islogin2==1){
	$price_obj = new Price($userrow['zid'],$userrow);
	$cookiesid = $userrow['zid'];
}elseif($is_fenzhan == true){
	$price_obj = new Price($siterow['zid'],$siterow);
}else{
	$price_obj = new Price(1);
}

$tid=intval($_GET['tid']);
$tool=$DB->get_row("select * from shua_tools where tid='$tid' limit 1");
if(!$tool || $tool['active']!=1)sysmsg('当前商品不存在');
if($tool['close']==1)sysmsg('当前商品维护中，停止下单！');

if(isset($price_obj)){
	$price_obj->setToolInfo($tool['tid'],$tool);
	if($price_obj->getToolDel($tool['tid'])==1)sysmsg('商品已下架');
	$price=$price_obj->getToolPrice($tool['tid']);
}else $price=$tool['price'];

if($tool['is_curl']==4){
	$count = $DB->count("SELECT count(*) FROM shua_faka WHERE tid='{$tool['tid']}' and orderid=0");
	$fakainput = getFakaInput();
	if($fakainput!='hide' && !$islogin2)$input=$fakainput;
	else $input=null;
	$isfaka = true;
}else{
	$input = $tool['input']?$tool['input']:'下单ＱＱ';
	$inputs = explode('|',$tool['inputs']);
	$isfaka = false;
}
if($tool['is_curl']==1||$tool['is_curl']==2||$tool['is_curl']==4){
	$isauto = true;
}else{
	$isauto = false;
}

include_once TEMPLATE_ROOT.'faka/head2.php';

?>
<div class="view w">
<input type="hidden" id="tid" value="<?php echo $tid?>">
<input type="hidden" id="leftcount" value="<?php echo $tool['is_curl']==2?100:$count?>">
  	<div class="bl_view_img"><img src="<?php echo $tool['shopimg']?$tool['shopimg']:'assets/faka/images/default.jpg';?>"  alt="<?php echo $tool['name']?>" /></div>
    <div class="bl_view_title"><?php echo $tool['name']?></div>
  <div class="bl_view_tag">
   		<div class="bl_view_price">售价：<?php echo $price?> 元</div>
    </div>
	<div class="bl_view_tag">
    	<div class="bl_view_user">商品类型：<?php echo $isauto?'<img src="assets/faka/images/zdfh.png">':'<img src="assets/faka/images/sdfh.png">';?>
</div>
    </div>
<?php if($isfaka){?>
	<div class="bl_view_title">商品库存：
 <font size="2" color="#FF7200"> 库存<?php echo $tool['is_curl']==2?'充足':$count.'个'?></span>
</div>
<?php }?>
<?php if($input){?>
<div class="bl_view_title"> <span id="inputname"><?php echo $input?>：</span>：<input class="search_input2" id="inputvalue" name="inputvalue" type="text" required></div>
<?php }else{?>
<input type="hidden" name="inputvalue" id="inputvalue" value="<?php echo $cookiesid?>"/>
<?php }?>
<?php if(is_array($inputs) && $inputs[0]){
$i=1;
foreach($inputs as $input){
$i++;
?>
<div class="bl_view_title"> <span id="inputname<?php echo $i?>"><?php echo $input?>：</span><input class="search_input2" id="inputvalue<?php echo $i?>" name="inputvalue<?php echo $i?>" type="text" required></div>
<?php }}?>
<?php if($tool['multi']==1){?>
	<div class="bl_view_title"> 购买数量：<input class="search_input2" id="num" name="num" type="number" value="1" min="1" max="<?php echo $count?>" placeholder="请输入购买数量" required></div>
<?php }?>
    <div class="go_buy"><input type="button" value="立即购买" id="submit_buy" /></div>
</div>
  <div class="bl_view_content w">
  	<h1>商品说明<span>具体使用方法请阅读商品说明</span></h1>
    <div class="bl_view_word">
    	    <p><?php echo $tool['desc']?></p> 
    </div>
  </div>

<div class="m_user w">
<a href="#">返回顶部</a>
</div>

<div class="copyright">Copyright &copy; 2020 <?php echo $conf['sitename']?></div>
</div>

<script src="<?php echo $cdnpublic?>jquery/1.12.4/jquery.min.js"></script>
<script src="<?php echo $cdnpublic?>layer/2.3/layer.js"></script>
<script src="<?php echo $cdnpublic?>jquery-cookie/1.4.1/jquery.cookie.min.js"></script>
<script type="text/javascript">
var hashsalt=<?php echo $addsalt_js?>;

$(window).load(function() {
	$("#status").fadeOut();
	$("#preloader").delay(350).fadeOut("slow");
})
$(document).ready(function(){
$("#submit_buy").click(function(){
	var tid=$('#tid').val();
	var num=$('#num').val();
	var leftcount=$('#leftcount').val();
	var inputvalue=$('#inputvalue').val();
	if(inputvalue=='' || tid==''){layer.alert('请确保每项不能为空！');return false;}
	var reg = /^([a-zA-Z0-9_-])+@([a-zA-Z0-9_-])+(.[a-zA-Z0-9_-])+/;
	if($('#inputname').html()=='你的邮箱：' && !reg.test(inputvalue)){layer.alert('邮箱格式不正确！');return false;}
	reg=/^[1][0-9]{10}$/;
	if($('#inputname').html()=='手机号码：' && !reg.test(inputvalue)){layer.alert('手机号码格式不正确！');return false;}
	var load=layer.load(2,{time:0,shade: [0.2,'#000']});
	$.post('ajax.php?act=pay', {tid:tid,inputvalue:inputvalue,inputvalue2:$("#inputvalue2").val(),inputvalue3:$("#inputvalue3").val(),inputvalue4:$("#inputvalue4").val(),inputvalue5:$("#inputvalue5").val(),num:num,hashsalt:hashsalt}, function(data){
		layer.close(load);
		if(data.code==0){
			$.cookie('email', inputvalue);
			window.location.href='./?mod=waporder&orderid='+data.trade_no;
		}else if(data.code == 1){
			alert('领取成功！');
			window.location.href='?buyok=1';
		}else if(data.code == 3){
			layer.alert(data.msg, {
				closeBtn: false
			}, function(){
				window.location.reload();
			});
		}else if(data.code == 4){
			var confirmobj = layer.confirm('请登录后再购买，是否现在登录？', {
			  btn: ['登录','注册','取消']
			}, function(){
				window.location.href='./user/login.php';
			}, function(){
				window.location.href='./user/reg.php';
			}, function(){
				layer.close(confirmobj);
			});
		}else{
			layer.alert(data.msg,{icon:2});
		}
	});
})
})
</script>
</body>
</html>
