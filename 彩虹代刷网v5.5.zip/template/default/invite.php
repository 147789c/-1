<?php
if(!defined('IN_CRONLITE'))exit();
if(!$conf['invite_tid'])exit("<script language='javascript'>alert('当前站点未开启推广链接功能');window.location.href='./';</script>");
$invite_row = $DB->get_row("select * from shua_tools where tid='{$conf['invite_tid']}' limit 1");
if(!$invite_row)exit("<script language='javascript'>alert('赠送商品ID不存在，请重新配置');window.location.href='./';</script>");

$tid = isset($_GET['tid'])?intval($_GET['tid']):0;
$shops = [
	['tid'=>1,'name'=>'超级会员','showname'=>'理论永久SVIP','shopimg'=>'./assets/img/yewu/svip.png','people'=>50],
	['tid'=>2,'name'=>'普通会员','showname'=>'理论永久VIP','shopimg'=>'./assets/img/yewu/vip.png','people'=>40],
	['tid'=>3,'name'=>'豪华黄钻','showname'=>'理论永久豪华黄钻','shopimg'=>'./assets/img/yewu/yellow.png','people'=>50],
	['tid'=>4,'name'=>'豪华绿钻','showname'=>'理论永久豪华绿钻','shopimg'=>'./assets/img/yewu/green.png','people'=>50],
	['tid'=>5,'name'=>'腾讯视频会员','showname'=>'理论永久腾讯视频会员','shopimg'=>'./assets/img/yewu/video.png','people'=>50],
	['tid'=>6,'name'=>'1千-10万名片赞','showname'=>'随机1千-10万名片赞','shopimg'=>'./assets/img/yewu/mpz.png','people'=>30],
];
?>
<!DOCTYPE html>
<html lang="zh-cn">
<head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no"/>
    <title><?php echo $conf['sitename']?> - 推广链接生成</title>
    <link href="<?php echo $cdnpublic?>twitter-bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet"/>
    <link href="<?php echo $cdnpublic?>font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet"/>
    <link rel="stylesheet" href="assets/simple/css/plugins.css">
    <link rel="stylesheet" href="assets/simple/css/main.css">
    <script src="<?php echo $cdnpublic?>modernizr/2.8.3/modernizr.min.js"></script>
    <!--[if lt IE 9]>
      <script src="<?php echo $cdnpublic?>html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="<?php echo $cdnpublic?>respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<body>
<br/>
<img src="<?php echo $background_image;?>" alt="Full Background" class="full-bg full-bg-bottom animated pulse " ondragstart="return false;" oncontextmenu="return false;">
<div class="col-xs-12 col-sm-10 col-md-8 col-lg-5 center-block" style="float: none;">
    <div class="block">
        <div class="block-title">
            <h2><i class="fa fa-share-alt"></i>&nbsp;&nbsp;<b>推广链接生成</b></h2>
        </div>
			<div class="form-group">
				<div class="alert alert-info alert-dismissable">
					<span id="loginmsg">提示：生成宣传语发给QQ好友、QQ群（互赞群，扩列群，互粉群）、QQ空间、朋友圈等地方宣传<hr>
<?php if($tid>0){?>
累积邀请<?php echo $shops[$tid-1]['people']?>位QQ好友访问后，即可获得<font color="red"><img src="<?php echo $shops[$tid-1]['shopimg']?>" width="20px"><?php echo $shops[$tid-1]['showname']?></font>
<?php }else{?>
					用户访问并购买商品后，即可获得<font color="red"><?php echo $invite_row['name']?></font></span><hr>
别人在你生成的{推广链接}无限下单，系统即会给{您的QQ}无限刷赞！<hr>
<?php 
foreach($shops as $row){
	echo '<a href="./?mod=invite&tid='.$row['tid'].'" class="btn btn-effect-ripple btn-default"><img src="'.$row['shopimg'].'" width="15px"><span style="font-weight:bold">领取'.$row['name'].'</span></a>&nbsp;';
}
?>
<?php }?>
				</div>
			<div class="form-group">
				<div class="input-group"><div class="input-group-addon">您的ＱＱ</div>
				<input type="text" name="userqq" id="userqq" class="form-control" placeholder="请输入您正确的QQ" required="required" onkeydown="if(event.keyCode==13){submit_sub.click()}"/>
			</div></div>
              <input type="submit" name="submit" id="submit_sub" value="立即生成推广链接" class="btn btn-primary btn-block"/>
			<div id="resulturl" style="display:none;">
			</div>
			</div>
			<hr>
			<div class="form-group">
			<a href="./" class="btn btn-primary btn-rounded"><i class="fa fa-home"></i>&nbsp;返回主页</a>
			<a href="user/regsite.php" class="btn btn-danger btn-rounded" style="float:right;"><i class="fa fa-user-plus"></i>&nbsp;开通分站</a>
			</div>
        </div>
	<div class="block">
<div class="block-title">
    <h2><i class="glyphicon glyphicon-stats"></i>&nbsp;&nbsp;<b>推广统计信息</b></h2>
</div>
<div style="margin: -20px -20px 20px;">
<div class="btn-group btn-group-justified">
<a target="_blank" class="btn btn-effect-ripple btn-default collapsed"><b><font color="modal-title">领取QQ</font></b></a>
<a target="_blank" class="btn btn-effect-ripple btn-default collapsed"><b><font color="modal-title">完成时间</font></b></a>
<a target="_blank" class="btn btn-effect-ripple btn-default collapsed"><b><font color="modal-title">获得奖励</font></b></a>
</div>
<marquee class="zmd" behavior="scroll" direction="UP" onmouseover="this.stop()" onmouseout="this.start()" scrollamount="5" style="height:16em">
	<table class="table table-hover table-striped" style="text-align:center">
		<thead>
<?php 
for($i=0;$i<80;$i++){
	$rand = $shops[array_rand($shops)];
	echo '<tr></tr><tr><td>恭喜QQ'.rand(11,999).'**'.rand(101,999).'**</td><td>于'.date("Y-m-d").'日推广成功</td><td><font color="salmon">奖励<img src="'.$rand['shopimg'].'" width="15">'.($rand==5?rand(2000,15000).'名片赞':$rand['name']).'</font></td></tr>';
}
?>
			
		</thead>
	</table>
</marquee>
</div>
    </div>
  </div>
<script src="<?php echo $cdnpublic?>jquery/1.12.4/jquery.min.js"></script>
<script src="<?php echo $cdnpublic?>twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="<?php echo $cdnpublic?>layer/2.3/layer.js"></script>
<script src="<?php echo $cdnpublic?>clipboard.js/1.7.1/clipboard.min.js"></script>
<script type="text/javascript">
var hashsalt=<?php echo $addsalt_js?>;
</script>
<script>
	var clipboard = new Clipboard('#copyurl');
	clipboard.on('success', function (e) {
		layer.msg('复制成功！');
	});
	clipboard.on('error', function (e) {
		layer.msg('复制失败，请长按链接后手动复制');
	});
	var clipboard = new Clipboard('#copycontent');
	clipboard.on('success', function (e) {
		layer.msg('复制成功！');
	});
	clipboard.on('error', function (e) {
		layer.msg('复制失败，请长按选中后手动复制');
	});
	$('#submit_sub').click(function(){
		var userqq = $('#userqq').val();
		if (userqq == '')
		{
			layer.alert('请确保每项不能为空！');
			return false;
		}
		var ii = layer.load(1, {shade: [0.1, '#fff']});
		$.ajax({
			type : 'POST',
			url : 'ajax.php?act=inviteurl',
			data : {userqq : userqq, hashsalt:hashsalt},
			timeout : 5000,
			dataType : 'json',
			async : true,
			success : function (json)
			{
				layer.close(ii);
				if (json.code === 1) {
					 var value = '特价名片赞0.1元起刷，免费领名片赞，免费拉圈圈99+，空间人气、QQ钻、大会员、名片赞、说说赞、空间访问、全民K歌，链接：' + json.url + ' (请复制链接到浏览器打开)';
                    $('#resulturl').html('<br><div class="list-group-item list-group-item-warning"><i class="fa fa-check-circle-o"></i>&nbsp;生成链接成功，请复制以下内容进行推广！</div><div class="col-xs-12 well well-sm">特价名片赞0.1元起刷<br>免费领名片赞，免费拉圈圈99+<br>空间人气、QQ钻、大会员、名片赞、说说赞、全民K歌<br><br>链接：' + json.url + '<br>(请复制链接到浏览器打开)</div><center><button class="btn btn-warning btn-sm" data-clipboard-text="'+json.url+'" id="copyurl">一键复制链接</button>&nbsp;<button class="btn btn-success btn-sm" data-clipboard-text="'+value+'" id="copycontent">一键复制广告语</button></center>');
				} else if (json.code === 2) {
					var value = '特价名片赞0.1元起刷，免费领名片赞，免费拉圈圈99+，空间人气、QQ钻、大会员、名片赞、说说赞、空间访问、全民K歌，链接：' + json.url + '(请复制链接到浏览器打开)';
                    $('#resulturl').html('<br><div class="list-group-item list-group-item-warning"><i class="fa fa-info-circle"></i>&nbsp;您已生成过链接，请复制以下内容进行推广！</div><div class="col-xs-12 well well-sm">特价名片赞0.1元起刷<br>免费领名片赞，免费拉圈圈99+<br>空间人气、QQ钻、大会员、名片赞、说说赞、空间访问、全民K歌、等等..<br>' + json.url + '<br>(请复制链接到浏览器打开)</div><center><button class="btn btn-warning btn-sm" data-clipboard-text="'+json.url+'" id="copyurl">一键复制链接</button>&nbsp;<button class="btn btn-success btn-sm" data-clipboard-text="'+value+'" id="copycontent">一键复制广告语</button></center>');
				} else {
					$('#resulturl').html('<br><div class="list-group-item list-group-item-warning"><i class="fa fa-close"></i>&nbsp;生成链接失败</div><div class="col-xs-12 well well-sm">'+json.msg+'</div>');
				} 
				$('#resulturl').slideDown();
			},
			error : function(){
				layer.close(ii);
				layer.alert('加载失败，请稍后再试！');
			}
			
		})
	})
</script>
</body>
</html>